sudo cp ./assertions.h /usr/include
sudo cp ./libassert.so /usr/lib
sudo /sbin/ldconfig
