void assert_iequals(int, int);
