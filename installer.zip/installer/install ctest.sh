sudo cp ./ctest /bin/
